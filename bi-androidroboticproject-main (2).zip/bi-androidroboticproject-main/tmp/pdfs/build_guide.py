from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Preformatted
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'output/pdf/ButtonDemo_Code_Explained.pdf'
OUT.parent.mkdir(parents=True, exist_ok=True)
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyGuide', fontName='Helvetica', fontSize=10, leading=13, spaceAfter=7, textColor=colors.HexColor('#243447')))
styles.add(ParagraphStyle(name='TitleGuide', fontName='Helvetica-Bold', fontSize=24, leading=28, spaceAfter=12, textColor=colors.HexColor('#123957')))
styles.add(ParagraphStyle(name='SubGuide', fontName='Helvetica-Bold', fontSize=13, leading=16, spaceBefore=9, spaceAfter=6, textColor=colors.HexColor('#176b92')))
styles.add(ParagraphStyle(name='CellGuide', fontName='Helvetica', fontSize=9, leading=11, textColor=colors.HexColor('#243447')))
styles.add(ParagraphStyle(name='CodeGuide', fontName='Courier', fontSize=8.6, leading=10.5, backColor=colors.HexColor('#eef3f7'), borderPadding=9, spaceBefore=5, spaceAfter=12))
story=[]
def p(s): story.append(Paragraph(s, styles['BodyGuide']))
def h(s): story.append(Paragraph(s, styles['SubGuide']))
def code(s): story.append(Preformatted(s, styles['CodeGuide']))
def table(headers, rows, widths=(155,344)):
    data=[[Paragraph('<b>'+escape(x)+'</b>',styles['CellGuide']) for x in headers]]
    data += [[Paragraph(escape(str(x)),styles['CellGuide']) for x in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dcebf3')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f4f7fa')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#aac5d7'))]))
    story.append(t); story.append(Spacer(1,10))
def page(n,title):
    if story: story.append(PageBreak())
    p('BUTTONDEMO / LEARNING GUIDE / '+str(n).zfill(2))
    story.append(Paragraph(title,styles['TitleGuide']))

page(1,'From your finger<br/>to the robot motors')
p('<b>A beginner-friendly guide to the ButtonDemo Android project</b><br/>Prepared 4 November 2026. Based on the project implementation discussed in this chat.')
p('The app does four jobs: it displays controls, interprets your finger movements, calculates two motor speeds, and sends those speeds to the robot over Bluetooth. This guide explains each layer and shows where to find its functions.')
h('The complete control path')
table(['Layer','What happens'],[
('1. Screen layout','XML creates the buttons, status labels and steering pad.'),
('2. Touch handling','MainActivity receives finger-down, movement and release events.'),
('3. Speed calculation','Buttons choose fixed speeds. DriveMixer calculates variable pad speeds.'),
('4. Command refresh','refreshDrive renews the desired speeds approximately every 100 ms.'),
('5. Robot protocol','ORB stores commands, encodes packets and sends them over Bluetooth.'),
('6. Robot hardware','The robot firmware interprets the packets and controls the motors.')])
p('<b>Drawing and driving are separate.</b> DrivePadView draws a dot. DriveMixer calculates speeds. MainActivity coordinates them. The ORB classes communicate with the robot.')
h('How to use this guide')
table(['Page','Topic'], [('2','Android basics and project organization'),('3','Layout, resources and app startup'),('4','Bluetooth connection and motor configuration'),('5','Complete MainActivity function and state reference'),('6','Touch events, buttons and stopping'),('7','Steering pad coordinates and motor mixing'),('8','Pad drawing and continuous command refresh'),('9','ORB protocol, communication and threads'),('10','Worked example, debugging and modification map')],(50,449))

page(2,'Android basics and project structure')
p('Android apps are <b>event-driven</b>. You do not write one main function that runs the whole interface from top to bottom. Android calls your methods when events happen: a screen opens, a button is touched, a permission is answered, or the user leaves the app. These automatically invoked methods are called callbacks.')
table(['Term','Meaning in this project'], [('Class','A definition of data and behavior, such as MainActivity or ORB.'),('Object','An instance of a class. The variable orb refers to an ORB object.'),('Method','A function belonging to a class, such as stopMotors().'),('Activity','An Android screen together with code managing that screen.'),('View','An interface element: a button, label or custom pad.'),('Listener','Code registered to react to events, such as touch events.'),('Resource','A layout, text string, theme or other packaged app content.'),('Thread','An execution path. Background threads can work alongside the interface thread.')])
code('private ORB orb;         // Declare a variable for an ORB object\norb = new ORB(this);     // Create the object')
p('Here, <b>this</b> means the current MainActivity object. <b>new</b> creates an object. <b>null</b> means a variable does not currently refer to an object. The annotation <b>@Override</b> marks a method that implements behavior defined by a parent class or interface.')
h('Where the files live')
code('ButtonDemo/\n  app/\n    build.gradle\n    src/main/\n      AndroidManifest.xml\n      java/com/hbrs/\n        MainActivity.java\n        DriveMixer.java\n        DrivePadView.java\n        Bluetooth/BT_DeviceListActivity.java\n        ORB/ ... robot communication classes ...\n      res/\n        layout/activity_main.xml\n        layout/device_list.xml\n        values/strings.xml\n        values/themes.xml')
p('All source-file references in this guide are relative to <b>ButtonDemo/app/src/main/</b>, unless stated otherwise. Java files use the package <b>com.hbrs</b>. The installed application ID is <b>com.hbrs.buttondemo</b>. Generated build folders are outputs, not the place to edit app behavior.')

page(3,'The screen and app startup')
p('<b>res/layout/activity_main.xml</b> defines the visible arrangement. Java supplies behavior. The layout contains a ScrollView, a vertical LinearLayout, connection status, Connect, driving status, Forward, a row of Left/Right buttons, Reverse, instructions and the custom DrivePadView.')
code('<Button android:id="@+id/Btn_1"\n    android:layout_width="match_parent"\n    android:layout_height="wrap_content"\n    android:text="@string/button_1" />')
p('This creates a button named Btn_1. <b>match_parent</b> fills the available parent width; <b>wrap_content</b> fits the content. Its text comes from strings.xml. The pad has a height of <b>300dp</b>; dp is a density-independent size unit. The ScrollView lets smaller screens scroll to the pad.')
h('How XML becomes accessible in Java')
code('setContentView(R.layout.activity_main);\nbutton1 = findViewById(R.id.Btn_1);')
p('Android generates the <b>R</b> resource class. R.layout.activity_main identifies the layout, R.id.Btn_1 identifies the button, and R.string.stopped identifies a text resource. findViewById retrieves the existing screen element; it does not create another button.')
h('onCreate() - MainActivity.java, line 86')
p('Android calls onCreate when it creates the activity. The method calls the parent initialization, enables edge-to-edge display, loads the layout and applies padding for system bars. It then finds the screen elements, creates the ORB object, registers listeners and disables driving controls until connection succeeds.')
code('buttonConnect.setOnClickListener(this::onClickConnect);\nbutton1.setOnTouchListener(new myOnTouchListener());')
p('The first line says: when Connect is clicked, call onClickConnect. The second creates a listener that receives touch events on Forward. The same touch-listener class is used for all four direction buttons and the pad.')
h('Configuration files')
table(['File','Role'], [('AndroidManifest.xml','Declares Bluetooth permissions, the device picker and MainActivity. MAIN/LAUNCHER identifies the activity opened from the app icon.'),('app/build.gradle','Uses Java 17, compileSdk/targetSdk 35, minSdk 23 and the application ID. Lists AndroidX dependencies.'),('strings.xml / themes.xml','Store labels/status messages and the AppCompat theme.'),('Root Gradle files / wrapper','Configure project modules, repositories and the build tool.')])
p('The Kotlin BOM in app/build.gradle aligns transitive Kotlin libraries used by dependencies. The app logic itself is written in Java; the BOM was added to resolve duplicate-library classes.')

page(4,'Connecting to the robot')
p('Connect does not drive the robot. It obtains permission, lets you select a paired device, opens a Bluetooth connection, configures the motors and enables the controls.')
table(['Step','Function and behavior'], [('1. Press Connect','MainActivity.onClickConnect() first stops current driving, then checks Bluetooth permission.'),('2. Permission result','onRequestPermissionsResult() continues to the picker if permission is granted; otherwise it displays a message.'),('3. Select device','BT_DeviceListActivity.onCreate() displays already paired devices. Selecting a row returns the Bluetooth address.'),('4. Receive result','MainActivity.onActivityResult() reads the selected BluetoothDevice and disables controls while connecting.'),('5. Background connection','connectionWorker runs orb.openBT(device), checks the result and configures M1/M4.'),('6. Update interface','runOnUiThread() updates the status and enables controls after a successful result.')])
h('The device picker')
p('<b>Bluetooth/BT_DeviceListActivity.java</b> has three main methods. <b>start()</b> (line 22) opens the picker. <b>onCreate()</b> (line 35) checks permission and Bluetooth availability and builds the device list. <b>getDeviceFromIntent()</b> (line 26) extracts the returned address and obtains a BluetoothDevice.')
p('An <b>Intent</b> is an Android message used here to launch another screen and carry result data. The picker uses getBondedDevices(), so the robot must already be paired in Android settings. It does not run a new discovery scan. Request codes 50 and 51 distinguish device selection and permission requests.')
h('Why connecting runs in the background')
code('connectionWorker.execute(() -> {\n    orb.openBT(device);\n    // Configure motors and determine connection result.\n    runOnUiThread(() -> {\n        // Update labels and enable controls.\n    });\n});')
p('The arrow syntax defines a lambda: a block of behavior supplied to another function. Opening Bluetooth can take time. The worker prevents that wait from freezing the interface. Screen updates return to the main thread through runOnUiThread.')
h('Motor configuration')
code('orb.configMotor(ORB.M1, 144, 50, 50, 30);\norb.configMotor(ORB.M4, 144, 50, 50, 30);')
p('The arguments are motor port, encoder ticks per rotation, acceleration, Kp and Ki. Kp/Ki tune the robot controller that regulates motor speed. The Android app supplies these settings; the robot firmware performs the regulation. Both motor target speeds are initially set to zero.')

page(5,'MainActivity function reference')
p('MainActivity is the coordinator. Locations below refer to <b>java/com/hbrs/MainActivity.java</b> in the source snapshot explained here; line numbers may move after future edits.')
table(['Method / line','Responsibility'], [('refreshDrive.run() / 56','Check active control and connection state; choose motor speeds; queue them; schedule the next refresh.'),('onCreate() / 86','Load the layout, find views, create ORB and register listeners.'),('onClickConnect() / 130','Stop driving, check permission and launch the picker.'),('onRequestPermissionsResult() / 141','Handle the permission answer.'),('onActivityResult() / 153','Receive selected device, connect, configure motors and enable controls.'),('onDestroy() / 203','Request stop, mark the activity destroyed and queue connection cleanup.'),('stopMotors() / 212','Cancel refreshing, clear active input, recenter the pad and queue zero speeds.'),('onPause() / 228','Stop when the activity is paused.'),('onWindowFocusChanged() / 234','Stop when the window loses focus.'),('updatePad() / 239','Convert pixel coordinates to normalized axes; calculate and store motor speeds; update the dot and text.'),('myOnTouchListener.onTouch() / 253','Handle finger down, move, release, cancellation and extra fingers.')])
h('State: what the activity remembers')
table(['Variable','Meaning'], [('orb','Object providing the robot API and communication.'),('motorsReady','The successful connection/configuration path has completed in this activity.'),('activeDriveButton','The View currently held. It can refer to the pad despite its name. null means no active control.'),('padM1 / padM4','Latest speeds calculated from the pad.'),('DRIVE_SPEED / DRIVE_REFRESH_MS','Base speed 500; refresh delay 100 milliseconds.'),('driveHandler / refreshDrive','Main-thread scheduler and the repeating command task.'),('connectionWorker / destroyed','Background connection executor and flag indicating activity destruction.')])
p('Fields belong to the activity object and remain available across callbacks. Local variables, such as speed inside run(), exist only during that method execution. The destroyed flag is volatile so changes can be observed by background work.')

page(6,'Touch events, buttons and stopping')
p('A held finger does not continuously call your code. Android reports a sequence of events. If the finger does not move, there may be no ACTION_MOVE events. This is why the app needs a separate repeating command task.')
code('ACTION_DOWN  ->  optional ACTION_MOVE events  ->  ACTION_UP')
table(['Event','Current behavior'], [('ACTION_DOWN','Check readiness, choose the active control, prevent parent scrolling, calculate pad values if needed and start refreshing.'),('ACTION_MOVE','For the pad: recalculate and send the latest speeds immediately. Fixed-direction buttons retain their direction.'),('ACTION_UP','End the gesture, cancel refreshing and request zero speed.'),('ACTION_CANCEL','Stop if Android cancels the gesture.'),('ACTION_POINTER_DOWN / UP','Stop when extra fingers join or leave a multiple-finger gesture.')])
p('In <b>onTouch(View v, MotionEvent e)</b>, v is the touched control and e contains the event type and local coordinates. Returning true says the event was handled. requestDisallowInterceptTouchEvent(true) prevents the surrounding ScrollView from taking the gesture while you steer.')
h('Fixed button commands')
p('Buttons use DRIVE_SPEED * 3, currently 1500. The current mapping treats M1 as the right wheel and M4 as the left wheel with opposite polarity.')
table(['Control','M1','M4'], [('Forward','+1500','-1500'),('Reverse','-1500','+1500'),('Left','+1500','+1500'),('Right','-1500','-1500')],(249,125,125))
p('The motors are mounted or wired with opposite orientations. Opposite command signs can therefore make both wheels roll forward. In SPEED_MODE, the library documents speed in thousandths of a rotation per second: 2500 requests 2.5 rotations per second, not 2500 percent. Actual speed depends on the hardware.')
h('stopMotors() is the shared stopping path')
p('It removes scheduled refresh callbacks, clears the pressed appearance and active control, resets pad speeds, centers the dot and queues zero for both motors. Release, cancellation, extra fingers, loss of focus, pausing and connection selection all use this function.')
p('On release, performClick() also invokes ordinary click handling. The click listeners request a stop, so clicks do not start indefinite motion. The status text "Stopped" means a zero-speed command was requested; it is not measured confirmation that the wheels have stopped.')

page(7,'Steering pad mathematics')
p('<b>MainActivity.updatePad()</b> first converts touch pixels into normalized coordinates. Android pixel coordinates start at the top-left, with Y increasing downward. The normalized axes put zero in the center and forward at positive Y.')
code('x = 2 * touchX / width - 1;\ny = 1 - 2 * touchY / height;\n\n                y = +1 (forward)\n                       |\nx = -1 (left) ------ (0,0) ------ x = +1 (right)\n                       |\n                y = -1 (reverse)')
p('For a 400 x 300 pixel pad, pixel (200,150) is the center, (200,0) is full forward and (400,150) is full right. The actual code protects against division by zero. Coordinates outside the pad are later clamped to the valid range.')
h('DriveMixer.axis() - line 7')
p('Each axis is limited to -1...+1. Magnitudes up to 0.08 become zero, creating a small central dead zone. Outside that zone, the remaining range is rescaled: <b>(magnitude - 0.08) / 0.92</b>, with the original sign restored. For example, 0.54 becomes 0.5.')
h('DriveMixer.mix() - line 14')
code('turn = axis(x);\nforward = axis(y);\nright = forward - turn;\nleft  = forward + turn;\nscale = max(1, abs(left), abs(right));\nM1 = round(right / scale * maxSpeed);\nM4 = -round(left / scale * maxSpeed);')
p('A right turn makes the left wheel faster than the right. If adjusted forward is 0.6 and turn is 0.2, wheel requests are right=0.4 and left=0.8. At maxSpeed=2500, the motor commands are M1=1000 and M4=-2000. Both values are divided by the same scale if either exceeds magnitude 1, preserving their ratio while respecting the speed limit.')
table(['Pad position','M1','M4'], [('Center','0','0'),('Top / bottom center','+2500 / -2500','-2500 / +2500'),('Middle right / left','-2500 / +2500','-2500 / +2500'),('Top-right corner','0','-2500'),('Top-left corner','+2500','0')],(249,125,125))
p('The pad uses DRIVE_SPEED * 5 = 2500. Horizontal input requests a turning direction, including during reverse. At the horizontal centerline it rotates on the spot; this is differential steering rather than a simulation of a car steering wheel.')

page(8,'Drawing the pad and keeping motion alive')
h('DrivePadView draws; it does not communicate')
table(['Method','Responsibility'], [('Constructor / line 16','Android creates the custom view from XML. The constructor makes it clickable.'),('setPosition() / line 21','Clamp and store the dot coordinates, then call invalidate().'),('onDraw() / line 28','Draw the background, crosshair, neutral zone, direction labels and position dot.')])
p('A <b>Canvas</b> is the drawing surface. <b>Paint</b> stores colors, line width and text settings. invalidate() requests a redraw; Android later calls onDraw(). The dot is blue when enabled and gray when disabled. Touch behavior is registered in MainActivity, not in this drawing class.')
h('Why the 100 ms refresh exists')
p('refreshDrive is a Runnable: an object containing a run() method. A Handler attached to Looper.getMainLooper() schedules that work on the main interface thread. Each execution checks the active control, chooses button speeds or padM1/padM4, updates both motor commands and schedules itself again.')
code('driveHandler.postDelayed(this, DRIVE_REFRESH_MS);')
p('This schedules another execution after approximately 100 ms. It does not pause the interface thread for 100 ms and is not a hard real-time guarantee. A held stationary finger still causes recurring commands because scheduling is independent of movement events.')
h('What happens when the finger moves')
p('The pad listener calls updatePad(), removes the existing pending refresh and runs refreshDrive immediately. That execution schedules one new callback. Removing the previous callback avoids accumulating multiple repeating tasks as many movement events arrive.')
h('What happens when the finger lifts')
code('driveHandler.removeCallbacks(refreshDrive);\nactiveDriveButton = null;\n// Reset pad state and request zero speed for both motors.')
p('All of this control state is handled on the main thread. A later refresh also exits if no control is active. The pad resets visually to the center, and a new touch is required to move again.')
h('The earlier few-seconds stop')
p('The ORB implementation sends motor-property packets only when their isNew flag is set. After sending, it clears that flag and sends other message types. A single setMotor() call therefore does not continually renew the motor packet. Repeating setMotor() renews the command while held. This explains the app-side change; the exact firmware timeout was not established from these Android files.')

page(9,'Robot protocol and execution threads')
p('Calling setMotor() stores a request; it does not directly write to Bluetooth. The ORB communication thread later encodes and transmits it.')
table(['Class','Functions and purpose'], [('ORB.java','Constructor creates transports and starts a thread. openBT() connects; configMotor()/setMotor() update command data; run() services communication; close() closes transports and requests loop shutdown.'),('cPropToORB.java','setMotor() stores mode, speed and position and sets isNew=true. fill() serializes motor/servo data into a byte buffer.'),('ORB_RemoteHandler.java','fill() chooses an outgoing message; process() parses received data; update() delegates to the active transport.'),('ORB_RemoteBT.java','open() creates a Bluetooth RFCOMM socket. updateOut() frames and writes packets; updateIn() reads them; update() services both; close() releases resources.'),('ORB_Remote.java','Shared transport abstraction and checksum calculation.')])
p('The cConfigToORB class holds configuration. cPropFromORB holds returned robot properties. cMonitorToORB/FromORB contain monitoring messages; cSettingsToORB/FromORB contain settings. ORB_RemoteUSB is the alternative USB transport, not the path selected by the Bluetooth picker.')
code('orb.setMotor(ORB.M1, ORB.SPEED_MODE, 1500, 0);\n// Arguments: motor port, mode, target speed, target position')
p('The position argument matters in position-movement mode; this app uses speed mode. ORB_RemoteHandler.fill() prioritizes pending settings, then configuration, then new motor/servo properties. Otherwise it sends monitoring data. Bluetooth output adds framing and a checksum before writing the packet bytes.')
h('Three execution contexts')
table(['Context','Work'], [('Android main/UI thread','Touch callbacks, screen drawing, labels and refreshDrive.'),('Connection worker','Potentially slow Bluetooth opening and queued cleanup.'),('ORB communication thread','Repeated protocol input/output; the loop sleeps briefly between iterations.')])
p('The UI and ORB threads share motor data. synchronized(orb.propToORB) protects updates to both motors. The packet sender uses the same lock when reading the properties and clearing isNew. This prevents a newly queued drive or stop command from being cleared while an older one is consumed.')
p('Bluetooth-connected status reflects the connection result, not continuously verified robot health. The existing transport does not robustly update that flag for every later I/O failure. Requested speed, measured wheel motion and connection status are separate pieces of information.')

page(10,'Read, trace and modify the project')
h('Trace one complete gesture')
p('<b>Touch top center:</b> onTouch receives ACTION_DOWN. updatePad converts the position to x=0, y=1. DriveMixer returns M1=2500 and M4=-2500. The pad dot moves to the top. refreshDrive stores those commands and schedules another execution.')
p('<b>Hold for one second:</b> scheduled refreshes continue approximately every 100 ms even if the finger never moves. The ORB thread sends the renewed motor packets.')
p('<b>Drag toward top-right:</b> ACTION_MOVE recalculates the mixture. M1 slows relative to the left wheel, producing a right turn. The latest values are queued immediately and then renewed while held.')
p('<b>Release:</b> ACTION_UP calls stopMotors. The refresh is cancelled, the pad recenters and both target speeds become zero. Actual stopping depends on delivery and the robot controller.')
h('Where to make common changes')
table(['Change','Location'], [('Button arrangement / pad height','res/layout/activity_main.xml'),('Button labels / status messages','res/values/strings.xml'),('Pad colors / labels / dot size','DrivePadView.onDraw()'),('Neutral-zone size','DriveMixer.axis(), currently 0.08'),('Steering behavior','DriveMixer.mix()'),('Fixed button speed','DRIVE_SPEED * 3 in refreshDrive.run()'),('Pad speed limit','DRIVE_SPEED * 5 in updatePad()'),('Refresh timing','DRIVE_REFRESH_MS in MainActivity'),('Touch and release handling','myOnTouchListener.onTouch()'),('Motor configuration','MainActivity.onActivityResult()'),('Bluetooth packet transport','ORB_RemoteBT')])
h('Recommended reading order')
p('Start with activity_main.xml and identify each control. Read onCreate to see how Java finds it. Next read onTouch, updatePad and DriveMixer. Read refreshDrive and stopMotors together. Finally follow ORB.setMotor into cPropToORB, then ORB_RemoteHandler.fill and ORB_RemoteBT.updateOut.')
h('Verification and scope')
p('The pad mathematics and custom view were compiled separately. A local calculation test covered the neutral zone, limits, turning, monotonic forward speed and 40,401 bounded pad positions. Those checks do not replace an Android build, screen test or robot test. Full build verification in the assistant environment was blocked by the previously reported Gradle loopback error.')
p('This guide explains the supplied project snapshot, not a general guarantee about hardware behavior. The motor-side mapping follows the latest code. If physical turning is reversed, inspect wiring and the mapping rather than assuming the interface labels prove wheel direction.')

def footer(canvas, doc):
    canvas.saveState()
    w,h=A4
    canvas.setStrokeColor(colors.HexColor('#d3dee7')); canvas.line(48,43,w-48,43)
    canvas.setFont('Helvetica',8); canvas.setFillColor(colors.HexColor('#53697d'))
    canvas.drawString(48,29,'ButtonDemo | Code explained | 4 November 2026')
    canvas.drawRightString(w-48,29,str(doc.page))
    canvas.restoreState()
doc=SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=38,bottomMargin=57,title='ButtonDemo - Code Explained',author='ButtonDemo project guide',subject='Android beginner guide: project organization, touch controls, steering pad and ORB Bluetooth protocol')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
reader=PdfReader(str(OUT))
print('PDF:',OUT)
print('Pages:',len(reader.pages))
for i,page in enumerate(reader.pages):
    text=page.extract_text()
    print(i+1,len(text),text[:75].replace('\n',' '))

