# RemoteControl

Android-Studio-Projekt nach `../bi-androidroboticproject-main/4_Project/ORB-Integration.md`.

## In Android Studio öffnen

1. Android Studio installieren und den Setup-Assistenten einschließlich Android SDK abschließen.
2. **Open** wählen und diesen Ordner `RemoteControl` öffnen (nicht den Kursordner und nicht nur `app`). Ein neues Projekt muss nicht erstellt werden.
3. Gradle Sync und die angeforderten SDK-Downloads zulassen. Verwendet werden Android SDK Platform 35, Android Gradle Plugin 8.9.2 und Gradle 8.11.1. Als Gradle JDK das mit Android Studio gelieferte JDK verwenden (mindestens JDK 17; Gradle 8.11.1 unterstützt bis JDK 23).
4. Ein Android-Handy ab Android 6 mit USB-Debugging verbinden und als Run-Gerät auswählen.
5. Den Roboter vorher in den Bluetooth-Einstellungen des Handys koppeln und Bluetooth einschalten.
6. App starten, **Connect** drücken, die Berechtigung für Geräte in der Nähe erlauben und den Roboter auswählen.
7. **Run** sendet M1 = +500 und M4 = -500 im SPEED_MODE. **Stop** setzt beide Geschwindigkeiten auf null.

Der Bluetooth-Hardwaretest benötigt ein echtes Android-Gerät und einen ORB-Roboter.

## Umgesetzter Stand

- Java, Paket und Application-ID `com.hbrs`, XML-Views mit RelativeLayout.
- Status-TextView, Connect/Run mit XML-onClick und Logcat-Ausgaben.
- Alle ORB-Java-Dateien sowie das Geräteauswahl-Layout aus dem Kurs übernommen.
- Manifest mit Bluetooth-Berechtigungen und BT_DeviceListActivity.
- Geräteauswahl mit Request-Code 50, ORB-Instanz in onCreate und openBT nach Auswahl.
- Motorkonfiguration für M1/M4 jeweils `(144, 50, 50, 30)`.
- Verbindung wird in onDestroy geschlossen.
- Zusätzlich: Status/Toast, Stop-Button, Stop-Befehl beim Verlassen der Activity, Verbindungsaufbau im Hintergrund.

Die kopierte Bluetooth-Geräteauswahl wurde für Android-Versionen vor/nach Android 12 angepasst und behandelt fehlendes Bluetooth, ausgeschaltetes Bluetooth und leere Gerätelisten. Sie verwendet Plattform-APIs, daher sind keine AndroidX-Abhängigkeiten nötig. Die ORB-Protokollklassen sind unverändert. Die Kursdateien im ursprünglichen Ordner bleiben unverändert.

Optionale Ultraschallsensor- und weitere Fahrmanöver-Aufgaben sind nicht implementiert.

## Prüfung

Projektstruktur, XML-Dateien, Ressourcenreferenzen und Übernahme der ORB-Klassen wurden lokal geprüft. Ein vollständiger Build und Hardwaretest stehen noch aus, da beim Anlegen kein JDK/Android-SDK installiert war.

Nach der Einrichtung kann im Terminal dieses Ordners zusätzlich geprüft werden:

```powershell
.\gradlew.bat assembleDebug lintDebug
```

Falls Java im Terminal nicht gefunden wird, über Android Studios Gradle-Fenster bauen oder JAVA_HOME auf das installierte JDK setzen. SDK-Pfade gehören in die von Android Studio erzeugte `local.properties` und werden nicht fest im Projekt hinterlegt.

Versionsreferenz: https://developer.android.com/build/releases/agp-8-9-0-release-notes
