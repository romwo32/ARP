**<u>Android Robotic Project</u>**

# Modulbeschreibung

## Umfang

- 1 SWS Vorlesung, 3 SWS Übung und Praktikum
- 6 ECTS-Credits

## Zuordnung

Bachelor Informatik, Spezialisierung Cyber-Physical-Systems
5. Semester

## Vorausgesetzte Vorkenntnisse

Grundlegende Kenntnisse der objektorientierten Softwareentwicklung in Java oder C++

## Angestrebte Lernergebnisse

- Kenntnisse des Betriebssystems Android und der Entwicklungsumgebung
- Grundlagenkenntnisse der Robotik bzw. mechatronischer Systeme
- Kompetenz in der Entwicklung von Android-Applikationen
- Fähigkeit, ein Android-System inklusive Sensorik zur Steuerung von Robotern zu nutzen

## Inhalt

Android-Systeme kombinieren hohe Rechenleistung, vielfältige Sensorik (u.a. Kamera) und grafische Benutzeroberfläche in einem Gerät. Im Rahmen eines konkreten Projektes werden diese Eigenschaften untersucht und diskutiert. Ziel ist dabei die Konstruktion eines autonomen Roboters, der in der Lage ist, eine gegebene Aufgabenstellung (z.B. Objektverfolgung oder Kartierung) zu lösen.

- Grundlagen des Android-Betriebssystems
- Java-Programmierung und Android Applikationsentwicklung
- Robotik, Sensorik und Aktuatorik

## Medienformen

Neben Folien und Tafelanschrieben werden Entwicklungsumgebungen, Android-Systeme und Roboter-Modelle praktisch eingesetzt.

## Literatur

- Koller D: Android-Apps programmieren. Franzis-Verlag, 2012
- Gargenta M: Einführung in die Android Entwicklung. O'Reilly, 2011
- Künneth T: Android 8. Das Praxisbuch für Java-Entwickler. Rheinwerk Computing, 2018
- Haun M: Handbuch Robotik. Programmieren und Einsatz intelligenter Roboter. Springer Vieweg, 2013
- Hertzberg J, Lingemann K, Nüchter A: Mobile Roboter. Eine Einführung aus Sicht der Informatik. Springer Vieweg, 2012
