//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   10.10.2025
\brief  DemoTimer
*/

//*******************************************************************

package com.hbrs;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Timer;
import java.util.TimerTask;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static final String TAG = "Timer";

    TextView textTimerTask;
    TextView textCountDown;
    TextView textRunnable;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textTimerTask = findViewById(R.id.textView_TimerTask);
        textCountDown = findViewById(R.id.textView_CountDown);
        textRunnable  = findViewById(R.id.textView_Runnable);


        //-----------------------------------------------------------------------------------------
        TimerTask timerTask = new TimerTask()
        {
            int cnt = 0;

            @Override
            public void run()
            {
                textTimerTask.setText("TimerTask: " + cnt);
                Log.i(TAG,"TimerTask: " + cnt);
				cnt++;
            }
        };

        Timer timer = new Timer();
        timer.schedule( timerTask, 1000,1000);
        //-----------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------
        CountDownTimer countDown = new CountDownTimer(10000, 1000)
        {
            @Override
            public void onTick(long millisUntilFinished)
            {
                textCountDown.setText("CountDown: seconds remaining=" + millisUntilFinished);
                Log.i(TAG,"CountDown: seconds remaining=" + millisUntilFinished);
            }

            @Override
            public void onFinish()
            {
                textCountDown.setText("CountDown: done!");
                Log.i(TAG,"CountDown: done!");
            }
        };

        countDown.start();
        //-----------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------
        Runnable runnable = new Runnable()
        {
            @Override
            public void run()
            {
                textRunnable.setText("Runnable: done!");
                Log.i(TAG,"Runnable: done!");
            }
        };

        Handler handler = new Handler();
        handler.postDelayed(runnable, 10000);
        //-----------------------------------------------------------------------------------------

    }
}