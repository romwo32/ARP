//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   10.10.2025
\brief  DemoToast
*/

//*******************************************************************
package com.hbrs;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static  String TAG = "Test";

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //-----------------------------------------------------------------
    public void onButtonMakeToast(View v)
    {
        Toast toast = Toast.makeText(this /* MyActivity */, "this is a toast", Toast.LENGTH_LONG);
        toast.show();

        // or:
        // Toast.makeText(context, text, duration).show();

    }
}
