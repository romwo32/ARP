//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   07.09.2021
\brief
*/

//*******************************************************************
package com.hbrs;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static final String TAG = "Test";

    TextView text1;
    Button button1;
    Button   button2;
    Button   button3;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txt = findViewById(R.id.Txt_1);
        txt.setText("Hello world");

        text1 = findViewById(R.id.Txt_1);

        button1 = findViewById(R.id.Btn_1);
        button2 = findViewById(R.id.Btn_2);
        button3 = findViewById(R.id.Btn_3);

        Button btn_2 = findViewById(R.id.Btn_2);
        btn_2.setOnClickListener(new myOnClickListener());
        button3.setOnTouchListener(new myOnTouchListener());
    }

    //-----------------------------------------------------------------
    public void myOnClick(View  view)
    {
        text1.setText("Button 1 clicked");
    }

    //-----------------------------------------------------------------
    class myOnClickListener implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            text1.setText("Button 2 clicked");
        }
    };

    //-----------------------------------------------------------------
    class myOnTouchListener implements View.OnTouchListener
    {
        @Override
        public boolean onTouch(View v, MotionEvent e) {
            float x = e.getX()/v.getMeasuredWidth();
            float y = e.getY()/v.getMeasuredHeight();
            switch(e.getAction())
            {
                case MotionEvent.ACTION_DOWN:
                    text1.setText("Button 3 clicked X="+String.format("%04.2f",x)+" Y="+String.format("%04.2f",y));
                    break;
                case MotionEvent.ACTION_MOVE:
                    text1.setText("Button 3 moved   X="+String.format("%04.2f",x)+" Y="+String.format("%04.2f",y));
                    break;
                case MotionEvent.ACTION_UP:
                    text1.setText("Button 3 released");
                    break;
                default:return false;
            }
            return true;
        }
    };
}