//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   10.10.2025
\brief  DemoThread
*/

//*******************************************************************
package com.hbrs;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static  String TAG = "Test";

    TextView textThread;

    Thread thread;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textThread = findViewById(R.id.textView_Thread);
    }

    //-----------------------------------------------------------------
    class ThreadExample extends Thread
    {
        int cnt = 0;

        @Override
        public void run()
        {
            while( !isInterrupted() )
            {
                textThread.setText(" " + cnt);
                Log.i(TAG, "" + cnt);
                cnt++;

                try {
                    sleep(100);
                } catch (InterruptedException e) {
                    interrupt();
                }
            }

            textThread.setText("done!");
            Log.i(TAG, "done!");
        }
    }

    //-----------------------------------------------------------------
    public void OnClick_Btn_StartStop(View  view)
    {
        if( thread !=null && thread.isAlive() )
        {
            thread.interrupt();
        }
        else
        {
          thread = new ThreadExample();
          thread.start();
        }
    }
}
