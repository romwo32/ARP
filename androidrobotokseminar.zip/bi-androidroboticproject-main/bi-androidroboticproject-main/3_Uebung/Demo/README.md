**<u>Android Robotic Project</u>**

# Demo

Dieses Verzeichnis enthält zu einigen Themen entsprechende Patches.
Zum Ausführen der Demos in Android Studio jeweils ein neues Projekt anlegen. Der Projekt Name muss den Namen der Demo enthalten. Folgendes Beispiel zeigt die Einstellungen für die Demo ***Activity***:

- `New Project: `*Empty Views Activity* 
  
  - `Name:             `*DemoActivity*
  - `Package name:     `*com.hbrs*
  - `select Language:  `*Java*

- Anschließend den Patch einspielen:
  Kopiere Demo-Verzeichnis `...\Uebung\Demo\Activity\*.*` in das Projekt-Verzeichnis `...\Work\DemoActivity\app\src\main\`
