//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   07.09.2021
\brief
*/

//*******************************************************************
package com.hbrs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

//*************************************************************************************************
public class SecondActivity extends AppCompatActivity
{
    private static final String TAG = "Test";
    private int num = 0;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Retrieve intent
        Bundle bundle = getIntent().getExtras();
        String msgFromMain = bundle.getString("msg");
        num = bundle.getInt("num");

        TextView text = findViewById(R.id.textMsg);
        text.setText("msg="+msgFromMain+"\nnum="+num);
    }

    //-----------------------------------------------------------------
    public void onBtnBack(View v)
    {
        // Create the result Intent
        Intent intent = new Intent();
        intent.putExtra("msg", "Reply from second activity");
        intent.putExtra("num", num+1);

        // Set result and finish this Activity
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}
