//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   07.09.2021
\brief
*/

//*******************************************************************
package com.hbrs;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static final String TAG = "Test";
    private int num = 0;
    private TextView text;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        text = findViewById(R.id.textMsg);
    }

    //-----------------------------------------------------------------
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);

        if( resultCode == Activity.RESULT_OK)
        {
            // Retrieve intent
            Bundle bundle = data.getExtras();

            String msgFromMain = bundle.getString("msg");
            num                = bundle.getInt("num");

            text.setText(  "req="+requestCode
                         + "\nResult OK"
                         + "\nmsg="+msgFromMain
                         + "\nnum="+num );
        }
        else
        {
            text.setText( "req="+requestCode
                         +"\nResult NOT OK"
                        + "\nres="+resultCode );
        }
    }

    //-----------------------------------------------------------------
    public void onBtnStart(View v)
    {
        // Create and fill intent
        Intent intent = new Intent(this, com.hbrs.SecondActivity.class);
        intent.putExtra("msg","Request from main activity");
        intent.putExtra("num",num);

        startActivityForResult(intent, 123);
    }


    //-----------------------------------------------------------------
    @Override
    protected void onStart()
    {
        super.onStart();
        Log.i(TAG, "onStart");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onResume()
    {
        super.onResume();
        Log.i(TAG, "onResume");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onPause()
    {
        super.onPause();
        Log.i(TAG, "onPause");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onStop()
    {
        super.onStop();
        Log.i(TAG, "onStop");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }

    //-----------------------------------------------------------------
    @Override
    public void onConfigurationChanged(Configuration config)
    {
        super.onConfigurationChanged(config);
        Log.i(TAG, "onConfigurationChanged");
    }

}