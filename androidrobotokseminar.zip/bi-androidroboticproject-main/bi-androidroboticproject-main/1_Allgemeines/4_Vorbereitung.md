**<u>Android Robotic Project</u>**

# Vorbereitung

1. Vorlesungsdokumente vom [GitLab des Fachbereiches](https://git.inf.h-brs.de/vorlesungen/bi-androidroboticproject) herunterladen.

2. Android Studio installieren
   
   - Download Android Studio https://developer.android.com/studio
   - Installationsdatei `android-studio-2025.1.3.7-windows.exe` ausführen. Während der Installation Standardeinstellungen verwenden.
   - GGf. `Setup JDK` mit *Android API 35, extension level 13* ausführen.

3. Android Studio Projekt anlegen
   
   - `New Project`: *Empty Views Activity*
     - `Name:            `*DemoActivity*
     - `Package name:    `*com.hbrs*
     - `select Language: `*Java*`
   - Projekt übersetzen und mit virtuellem Device testen

4. Debugging auf Android-Gerät vorbereiten
   
   - Auf dem Gerät Entwickleroptionen aktivieren. 
     
     - In Geräteinformationen 7x auf `Buildnummer` tippen: In den Geräteeinstellung erscheint einer neuer Eintrag *Entwickleroptionen*. 
     - USB-Debuggig freigeben.
   
   - USB-Kabel anschließen, das angeschlossene Device erscheint im `Device Manager`
   
   - Alternativ zum USB -Debugging ist auch das Debugging über WLAN möglich