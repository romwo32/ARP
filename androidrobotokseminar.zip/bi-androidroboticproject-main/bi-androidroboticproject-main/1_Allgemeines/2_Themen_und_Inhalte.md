**<u>Android Robotic Project</u>**

# Themen und Inhalte

- Einführung in Android

- Elemente der Android-Programmirung
  
  - Activity
  
  - View und Layout
  
  - Intent
  
  - Timer
  
  - Thread

- Grundlagen der Robotik

- Bluetooth

- Kamera und Objekterkennung

- Objektverfolgung