**<u>Android Robotic Project</u>**

## Informationen zur Vorlesung

### Umfang

- 1 SWS Vorlesung, 3 SWS Übung und Praktikum (~ 60h pro Semester)
- 6 ECTS-Credits (180h pro Semester)

### Inhalt

Android-Systeme kombinieren hohe Rechenleistung, vielfältige Sensorik (u.a. Kamera) und grafische Benutzeroberfläche in einem Gerät. Im Rahmen eines konkreten Projektes werden diese Eigenschaften untersucht und diskutiert. Ziel ist dabei die Konstruktion eines autonomen Roboters, der in der Lage ist, eine gegebene Aufgabenstellung (z.B. Objektverfolgung oder Kartierung) zu lösen.

- Grundlagen des Android-Betriebssystems
- Java-Programmierung und Android Applikationsentwicklung
- Robotik, Sensorik und Aktuatorik

### Studienleistung

Semesterbegleitende Prüfung

- Demonstration und Erläuterung des Robotik-Projektes
- Vollständiges Software-Projektverzeichnis
- Projektdokumentation
- Abgabe: Datei-Upload in LEA, Termin beachten!

### Literaturhinweis

Hier finden Sie weiterfühende Literatur zu den Vorlesungsinhalten, die für das Verständnis der Vorlesung nützlich sein können.

### Dokumente und Dateien:

- Wichtige Aushänge, Dokumente und sonstige Dateien zur Vorlesung finden Sie unter LEA bzw. im Git-Lab des Fachbereiches.

### Individuelle Sprechstunde:

- Nach Vereinbarung