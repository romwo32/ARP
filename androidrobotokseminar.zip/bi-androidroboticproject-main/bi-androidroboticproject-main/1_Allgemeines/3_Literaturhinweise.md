**<u>Android Robotic Project</u>**

# Literaturhinweise

- https://developer.android.com/

- https://developer.android.com/studio

- https://www.programmierenlernenhq.de/android-app-programmieren-tutorial

- https://www.tutlane.com/tutorial/android

- https://www.big-app.de/wifi-debugging-einrichten

- Android-Programmierung, Z. Mednieks, O'Reilly, 2013

- Android-Apps programmieren, D. Koller, Franzis, 2012

- Einführung in die Android Entwicklung, M. Gargenta, O'Reilly, 2011
