**<u>Android Robotic Project</u>**

# Robot control integration

## Software download

Get *4_Project\ORB* from https://git.inf.h-brs.de/vorlesungen/bi-androidroboticproject

## Create new Project with Android Studio

`New Project`: *Empty Views Activity*

- `Name:            `*RemoteControl*
- `Package name:    `*com.hbrs*
- `select Language: `*Java*

## Goto layout file *activity_main.xml*

- Convert view to *Relative Layout*
- Change 'id' of given TextView
- Add Button 'Connect' and 'Run'
  - set attribute 'id'
  - set attribute 'text'
  - set attribute 'onClick'

## Goto file *MainActivity.java*

- Add method `onClickConnect()` and `onClickRun()`
- Use Logcat and/or TextView to test buttons

## Patch Software

Copy content of 4_Project\ORB to RemoteControl\app\src\main\

## Goto file *AndroidManifest.xml*

- Add permission on top level:

```
<uses-permission android:name="android.permission.BLUETOOTH" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
```

- Add new activity

```
<activity android:name=".Bluetooth.BT_DeviceListActivity"
          android:label="Select BT Device"
          android:theme="@android:style/Theme.Dialog" />
```

## Goto file *MainActivity.java*

- Add to method `onClickConnect()`:

```
BT_DeviceListActivity.start(this, 50);
```

- Add method

```
@Override
public void onActivityResult(int requestCode, int resultCode, Intent data)
{
  super.onActivityResult(requestCode,resultCode,data);
  switch(requestCode)
  {
    case 50:
      switch(resultCode)
      {
        case BT_DeviceListActivity.RESULT_OK:
          Log.i("Test",BT_DeviceListActivity.getDeviceFromIntent(data).toString());
          break;
        case BT_DeviceListActivity.RESULT_CANCELED:
          Log.i("Test","canceled");
          break;
        default:
          Log.i("Test", "Enable permissons first");
          break;
        }
        break;
      }
    }
```

## <u>Test the app</u>

- Set permission in android settings menu

## Goto file *MainActivity.java*

- Add member 
  
  ```
  ORB orb;
  ```

- Instanziate `orb` in `onCreate()`:
  
  ```
  orb = new ORB( this );
  ```

- Open connecten in `onActivityResult()`:

```
orb.openBT( BT_DeviceListActivity.getDeviceFromIntent(data));
```

- Send motor configuration to ORB in `onActivityResult()`:

```
orb.configMotor(ORB.M1, 144, 50, 50, 30);
orb.configMotor(ORB.M4, 144, 50, 50, 30);
```

- Close connection in `onDestroy()`:
  
  ```
  @Override
  public void onDestroy()
  {
    orb.close();
    super.onDestroy();
  }
  ```

- Send run command in `onClickRun()`:
  
  ```
  orb.setMotor( ORB.M1, ORB.SPEED_MODE, +500, 0);
  orb.setMotor( ORB.M4, ORB.SPEED_MODE, -500, 0);
  ```

## *<u> Test the app</u>*

## Next steps

- Display robots name or connection state with TextView, use ```orb.getDeviceName()```

- Use 
  ```Toast.makeText(this, "...", Toast.LENGTH_SHORT).show();```
  to inform use about connection state

- Add more buttons an perform different robot manoevers

- Use `View.OnTouchListener` (see 3_Uebung/Demo/View) to refine remote control

## Option

### Ultrasonic Sensor

You can add an ultrasonic distance sensor to your robot.

- Configure the sensor by calling the method
  ```orb.configSensor( <port id>, 3, 0, 0 )```
  once at start up, e.g. onCreate()

- Call
  ```orb.getSensorValue( <port id> )```
  to get the sensor readings