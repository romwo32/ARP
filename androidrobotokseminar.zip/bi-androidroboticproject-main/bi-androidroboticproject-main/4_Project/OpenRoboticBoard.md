**<u>Android Robotic Project</u>**

# Open Robotic Board

The Open Robotic Board (ORB) is an open source project.


[Complete project documenation](https://github.com/ThBreuer/OpenRoboticBoard)


[Schematics and layout (KiCAD)](https://github.com/ThBreuer/ORB-Hardware)
