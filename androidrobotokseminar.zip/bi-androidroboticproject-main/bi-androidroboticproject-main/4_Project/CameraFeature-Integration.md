**<u>Android Robotic Project</u>**

# Camera feature integration

## Camera Preview

### Dependencies

The camera API needs additional libraries.

- Todo: Goto *Menu - File - Project-Structure / Dependencies* and add libraries:  
  - androidx.camera:camera-camera2
  - androidx.camera:camera-core
  - androidx.camera:camera-lifecycle
  - androidx.camera:camera-view

### Permissions

- Todo: Add camera permission in `AndroidManifest.xml`

```
<manifest ...>
...
<uses-permission android:name="android.permission.CAMERA"/>
</manifest>
```

- With Android 6.0 (API level 23) the permissions must also be set by 
  *Android - Settings - App - ...*  or use `requestPermissions()`

### Preview-View

- Todo: Add a `PreviewView `to the layout (`activity_main.xml`)

```
<androidx.camera.view.PreviewView 
        android:id="@+id/previewView" />
```

- Todo: Add missing constraints as suggested by Android Studio

### Implement a Preview Use Case

The camera provider is a `ListenableFuture` object, which represents the result of an asynchronous computation like using a camera. A registered callback will be executed (by the `Executor`) once the computation is complete.

- Todo: Insert camera provider request in  `onCreate()`
  
  ```
  ListenableFuture<ProcessCameraProvider> cameraProviderFuture 
  = ProcessCameraProvider.getInstance(this);
  ```

- Import classes as suggested by Android Studio

- Add listener to the camera provider
  
  - Todo: Insert code in `onCreate()`

```
cameraProviderFuture.addListener(new Runnable() 
{
  @Override
  public void run() 
  {
    try {
      ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
      MainActivity.this.bindPreview(cameraProvider);
    } 
    catch (ExecutionException | InterruptedException e) {
      // No errors need to be handled for this Future.
      // This should never be reached.
    }
  }
}, ContextCompat.getMainExecutor(this));
```

The `run()`-method is called on every new camera setting. 

A `ProcessCameraProvider` is a singelton, providing basic access to the cameras. The application has to define and bind a lifecycle to the provider. This lifecycle lists the use-cases (*what should be done with the picture?*). Here we bind the preview to the camera provider. The preview is then executed with every new picture.

- Todo: Define a `bindPreview()` - method

```
void bindPreview(ProcessCameraProvider cameraProvider) 
{
  // use case: select a camera
  CameraSelector cameraSelector 
    = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

  // use case: preview
  Preview     preview     = new Preview.Builder().build();
  PreviewView previewView = findViewById(R.id.previewView);
  preview.setSurfaceProvider(previewView.getSurfaceProvider());

  // bind all use cases (maximum 3) to the camera provider
  Camera camera = cameraProvider.bindToLifecycle((LifecycleOwner)this, 
                                                 cameraSelector, 
                                                 preview);
}
```

## <u>Test the app</u>

- Set camera permission in android settings menu

## Implement an Image Analysis Use Case

In this use case we can implement image processing

### Output View

This second view is intended to output an processed image

- Todo: Add an `ImageView `to the layout (`activity_main.xml`)

```
 <ImageView
        android:id="@+id/imageView"
 />
```

- Todo: Add missing constraints as suggested by Android Studio

### Image Analyzer Class

This class should implement all image processing stuff

- Todo: Add class to `MainActivity`-class
  
  ```
  class MyAnalyzer implements ImageAnalysis.Analyzer 
  {  
    @Override  
    public void analyze(ImageProxy imageProxy) 
    {  
        Bitmap bm = imageProxy.toBitmap();  
  
        //... do something with the bitmap image ...
  
        ImageView imageView = findViewById(R.id.imageView);  
        imageView.setImageBitmap(bm);  
        imageProxy.close();  
    }  
  }
  ```

### Analysis Use Case

- Instantiate a `MyAnalyzer`- and a `ImageAnalysis`-object. Tell the `ImageAnalysis`-object to use `MyAnalyzer`-object.
  
  - Todo: Insert code in  `bindPreview()`

```
MyAnalyzer    analyzer = new MyAnalyzer();

ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()  
               .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)  
               .build();  

imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), 
                          analyzer);  
```

- Add the `ImageAnalysis`-object to the camera provider lifecycle
  
  - Todo: Replace code

```
Camera camera = cameraProvider.bindToLifecycle((LifecycleOwner)this, 
                                               cameraSelector, 
                                               imageAnalysis, 
                                               preview);
```

## <u>Test the app</u>

## Image Processing

The image processing can be implemented within `MyAnalyzer.analyze()`.
In this example, the image is represented in a `Bitmap`-object. The processing output is viewed in an `ImageView`-objekt. Now the `Bitmap`-methods (e.g. `getPixel()`, `getWidth()`, ... ) can be used to process the image. 
A `Canvas `and `Paint`-object can be used to draw lines, textes and much more on the output image.

### Drawing on the Bitmap

- Create a Canvas object using the bitmap
- Create a Paint object
- Set color and style of the Paint object
- Use a Canvas.draw...() method
- Output the modified Bitmap

```
Bitmap bm = imageProxy.toBitmap();

Canvas canvas = new Canvas(bm);

Paint p = new Paint();
p.setColor(Color.YELLOW);
p.setStyle(Paint.Style.STROKE);

canvas.drawCircle(bm.getWidth() / 2, bm.getHeight() / 2, bm.getWidth() / 4, p);

ImageView imageView = findViewById(R.id.imageView);  
imageView.setImageBitmap(bm);
```

## Reference

[Android for Developers - CameraX overview](https://developer.android.com/training/camerax)
