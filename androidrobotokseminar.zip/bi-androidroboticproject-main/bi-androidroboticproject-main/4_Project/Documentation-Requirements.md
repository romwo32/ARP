# Documentation Requirements

The documentation should enable an outside reader to understand your project.

## Introduction

- Project requirements (e.g. specify object, geometrie, color, scenario,...)
- Robot construction and communication with android device
- Robot behaviour (e.g. if robot is not detected)
- optional: given hardware, state of the art

## Method

- Used Tools (Editor, Compiler etc.)
- SW development process (incremental, extreme programming, Scrum,...)
- Team organisation
- SW versioning, merge

## Concept

   (unsorted) collection of

- ideas

- paper work

- discussion

- drafts and sketches

- problems and solutions

## Architecture and Design

- flow chart

- class diagram

- other UML diagrams

- Libraries (OpenMV, MBot,...)

- code fragments, pseudocode

## Test and Validation

- Test specification (specify a test that can be performed externally)
  
  - Setup, SW Installation
  - Scenario
  - expected robot behaviour
  - checklist

- Test results (from external test team) with OK/Not OK

## Evaluation

- Evaluate and discuss test results from an neutral point of view
- optional: Conclusion and summary
