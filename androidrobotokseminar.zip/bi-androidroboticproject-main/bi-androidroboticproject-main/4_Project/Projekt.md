**<u>Android Robotic Project</u>**

# Projektaufgabe

In diesem Projekt soll eine Android-Applikation zur Steuerung eines mobilen Roboters entwickelt werden. Der Roboter soll mit Hilfe einer Kamera einem vorgegeben Objekt autonom folgen können. 
<img title="" src="mBotRanger.jpg" alt="mBot Ranger" width="397" data-align="inline">

Als Zielobjekt kann ein beliebiger Gegenstand verwendet werden, es empfiehlt sich ein einfarbiges, rundes Objekt (z.B. ein roter Ball).

Der zu steuernde Roboter ist ein "mBot Ranger" (Fa. Makeblock). 

Abweichend zur Abbildung werden in diesem Projekt keine Sensoren verwendet. Statt dessen soll das Android-Gerät in geeigneter Weise am Roboter angebracht werden. Über eine Bluetooth-Verbindung kann das Android-Gerät Steuerkommandos an die Aktoren des Roboters senden.

Die App soll unter Android-Studio in Java entwickelt werden. Als Ausgangspunkt der Entwicklung kann das vorbereitete verwendet werden, das auch die Klassen zur Übertragung von Steuerkommandos an den Roboter enthält.
