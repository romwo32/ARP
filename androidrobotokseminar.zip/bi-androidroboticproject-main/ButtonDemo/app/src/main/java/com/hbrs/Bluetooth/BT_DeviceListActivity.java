package com.hbrs.Bluetooth;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.hbrs.R;
import java.util.ArrayList;

/** Paired-device picker adapted from the supplied course implementation. */
public class BT_DeviceListActivity extends Activity {
    public static final int RESULT_NOPERMISSION = Activity.RESULT_FIRST_USER;
    public static final String EXTRA_DEVICE_ADDRESS = "device_address";

    public static void start(Activity parent, int requestCode) {
        parent.startActivityForResult(new Intent(parent, BT_DeviceListActivity.class), requestCode);
    }

    public static BluetoothDevice getDeviceFromIntent(Intent data) {
        if (data == null) return null;
        String address = data.getStringExtra(EXTRA_DEVICE_ADDRESS);
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || address == null || !BluetoothAdapter.checkBluetoothAddress(address)) return null;
        return adapter.getRemoteDevice(address);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            setResult(RESULT_NOPERMISSION);
            finish();
            return;
        }
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            Toast.makeText(this, "Bluetooth ist nicht verfügbar oder ausgeschaltet.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        setContentView(R.layout.device_list);
        ArrayList<BluetoothDevice> devices = new ArrayList<>(adapter.getBondedDevices());
        ArrayList<String> labels = new ArrayList<>();
        for (BluetoothDevice device : devices) {
            String name = device.getName();
            labels.add((name == null ? "Unbekanntes Gerät" : name) + "\n" + device.getAddress());
        }
        ListView list = findViewById(R.id.paired_devices);
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
        list.setOnItemClickListener((parent, view, position, id) -> {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_DEVICE_ADDRESS, devices.get(position).getAddress()));
            finish();
        });
        if (devices.isEmpty()) {
            Toast.makeText(this, "Zuerst den Roboter in den Android-Bluetooth-Einstellungen koppeln.", Toast.LENGTH_LONG).show();
            finish();
        }
    }
}
