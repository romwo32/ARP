package com.hbrs;

/** Differential steering, matching the existing left/right button wiring. */
public final class DriveMixer {
    private DriveMixer() {}

    private static float axis(float value) {
        value = Math.max(-1f, Math.min(1f, value));
        float magnitude = Math.abs(value);
        return magnitude <= 0.08f ? 0f : Math.copySign((magnitude - 0.08f) / 0.92f, value);
    }

    // x: right positive; y: forward positive. M1 right, M4 left (opposite polarity).
    public static int[] mix(float x, float y, int maxSpeed) {
        float turn = axis(x);
        float forward = axis(y);
        float right = forward - turn;
        float left = forward + turn;
        float scale = Math.max(1f, Math.max(Math.abs(left), Math.abs(right)));
        return new int[]{Math.round(right / scale * maxSpeed),
                -Math.round(left / scale * maxSpeed)};
    }
}
