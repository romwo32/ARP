package com.hbrs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Fixed-center touch pad with a visible finger position and neutral zone. */
public class DrivePadView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float x;
    private float y;

    public DrivePadView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setClickable(true);
    }

    public void setPosition(float x, float y) {
        this.x = Math.max(-1f, Math.min(1f, x));
        this.y = Math.max(-1f, Math.min(1f, y));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        float density = getResources().getDisplayMetrics().density;
        paint.setColor(Color.rgb(225, 235, 245));
        canvas.drawRoundRect(0, 0, w, h, 16 * density, 16 * density, paint);
        paint.setColor(Color.rgb(152, 174, 198));
        paint.setStrokeWidth(2 * density);
        canvas.drawLine(w / 2, 0, w / 2, h, paint);
        canvas.drawLine(0, h / 2, w, h / 2, paint);
        paint.setColor(Color.rgb(190, 207, 223));
        canvas.drawRect(w * .46f, h * .46f, w * .54f, h * .54f, paint);
        paint.setColor(Color.rgb(43, 66, 89));
        paint.setTextSize(14 * density);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("VORWÄRTS", w / 2, 25 * density, paint);
        canvas.drawText("RÜCKWÄRTS", w / 2, h - 13 * density, paint);
        canvas.drawText("LINKS", 36 * density, h / 2 - 10 * density, paint);
        canvas.drawText("RECHTS", w - 40 * density, h / 2 - 10 * density, paint);
        paint.setColor(isEnabled() ? Color.rgb(25, 110, 210) : Color.GRAY);
        canvas.drawCircle((x + 1) * w / 2, (1 - y) * h / 2, 15 * density, paint);
    }
}
