//*******************************************************************
/*!
\file   MainActivity.java
\author Thomas Breuer
\date   07.09.2021
\brief
*/

//*******************************************************************
package com.hbrs;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import com.hbrs.Bluetooth.BT_DeviceListActivity;
import com.hbrs.ORB.ORB;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//*************************************************************************************************
public class MainActivity extends AppCompatActivity
{
    private static final String TAG = "Test";
    private static final int SELECT_DEVICE = 50;
    private static final int CONNECT_PERMISSION = 51;
    private final ExecutorService connectionWorker = Executors.newSingleThreadExecutor();
    private ORB orb;
    private Button buttonConnect;
    private TextView connectionStatus;
    private volatile boolean destroyed;
    private boolean motorsReady;
    private View activeDriveButton;
    private DrivePadView drivePad;
    private int padM1;
    private int padM4;
    private static final int DRIVE_SPEED = 500;
    private static final long DRIVE_REFRESH_MS = 100;
    private final Handler driveHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshDrive = new Runnable() {
        @Override
        public void run() {
            if (activeDriveButton == null) return;
            if (destroyed || !motorsReady || !orb.orb_BT.isConnected()) {
                stopMotors();
                return;
            }
            int speed = DRIVE_SPEED * 3;
            // Preserve the current button wiring (M1 right, M4 left, opposite polarity).
            int m1 = (activeDriveButton == button2 || activeDriveButton == buttonRight) ? -speed : speed;
            int m4 = (activeDriveButton == button2 || activeDriveButton == buttonLeft) ? speed : -speed;
            if (activeDriveButton == drivePad) {
                m1 = padM1;
                m4 = padM4;
            }
            // setMotor marks the command as new; otherwise ORB sends only monitor packets.
            synchronized (orb.propToORB) {
                orb.setMotor(ORB.M1, ORB.SPEED_MODE, m1, 0);
                orb.setMotor(ORB.M4, ORB.SPEED_MODE, m4, 0);
            }
            driveHandler.postDelayed(this, DRIVE_REFRESH_MS);
        }
    };
    TextView text1;
    Button button1;
    Button   button2;
    Button buttonLeft;
    Button buttonRight;

    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txt = findViewById(R.id.Txt_1);
        txt.setText("Hello world");

        text1 = findViewById(R.id.Txt_1);

        button1 = findViewById(R.id.Btn_1);
        button2 = findViewById(R.id.Btn_2);
        buttonLeft = findViewById(R.id.Btn_Left);
        buttonRight = findViewById(R.id.Btn_Right);
        drivePad = findViewById(R.id.drivePad);
        buttonConnect = findViewById(R.id.buttonConnect);
        connectionStatus = findViewById(R.id.connectionStatus);
        buttonConnect.setOnClickListener(this::onClickConnect);
        orb = new ORB(this);

        button1.setOnTouchListener(new myOnTouchListener());
        button2.setOnTouchListener(new myOnTouchListener());
        buttonLeft.setOnTouchListener(new myOnTouchListener());
        buttonRight.setOnTouchListener(new myOnTouchListener());
        drivePad.setOnTouchListener(new myOnTouchListener());
        drivePad.setOnClickListener(v -> stopMotors());
        drivePad.setEnabled(false);
        // Clicks (including accessibility clicks) stop; movement requires a held touch.
        button1.setOnClickListener(v -> stopMotors());
        button2.setOnClickListener(v -> stopMotors());
        buttonLeft.setOnClickListener(v -> stopMotors());
        buttonRight.setOnClickListener(v -> stopMotors());
        button1.setEnabled(false);
        button2.setEnabled(false);
        buttonLeft.setEnabled(false);
        buttonRight.setEnabled(false);
        text1.setText(R.string.drive_hint);
    }

    public void onClickConnect(View view) {
        stopMotors();
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, CONNECT_PERMISSION);
            return;
        }
        BT_DeviceListActivity.start(this, SELECT_DEVICE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == CONNECT_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                onClickConnect(buttonConnect);
            } else {
                connectionStatus.setText(R.string.bluetooth_permission_denied);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SELECT_DEVICE) return;
        if (resultCode == BT_DeviceListActivity.RESULT_NOPERMISSION) {
            connectionStatus.setText(R.string.bluetooth_permission_denied);
            return;
        }
        if (resultCode != RESULT_OK) return;
        BluetoothDevice device = BT_DeviceListActivity.getDeviceFromIntent(data);
        if (device == null) return;
        motorsReady = false;
        drivePad.setEnabled(false);
        button1.setEnabled(false);
        button2.setEnabled(false);
        buttonLeft.setEnabled(false);
        buttonRight.setEnabled(false);
        buttonConnect.setEnabled(false);
        connectionStatus.setText(R.string.connecting);
        connectionWorker.execute(() -> {
            if (destroyed) return;
            boolean connected = false;
            try {
                orb.openBT(device);
                connected = orb.orb_BT.isConnected();
                if (connected) {
                    orb.configMotor(ORB.M1, 144, 50, 50, 30);
                    orb.configMotor(ORB.M4, 144, 50, 50, 30);
                    orb.setMotor(ORB.M1, ORB.SPEED_MODE, 0, 0);
                    orb.setMotor(ORB.M4, ORB.SPEED_MODE, 0, 0);
                }
                if (!connected) orb.orb_BT.close();
            } catch (SecurityException e) {
                orb.orb_BT.close();
            }
            final boolean success = connected;
            runOnUiThread(() -> {
                if (destroyed) return;
                buttonConnect.setEnabled(true);
                motorsReady = success;
                drivePad.setEnabled(success);
                button1.setEnabled(success);
                button2.setEnabled(success);
                buttonLeft.setEnabled(success);
                buttonRight.setEnabled(success);
                connectionStatus.setText(success ? R.string.connected : R.string.connection_failed);
            });
        });
    }

    @Override
    protected void onDestroy() {
        stopMotors();
        destroyed = true;
        // Serialize cleanup with the pending connection attempt.
        connectionWorker.execute(() -> orb.close());
        connectionWorker.shutdown();
        super.onDestroy();
    }

    private void stopMotors() {
        driveHandler.removeCallbacks(refreshDrive);
        if (activeDriveButton != null) activeDriveButton.setPressed(false);
        activeDriveButton = null;
        padM1 = padM4 = 0;
        if (drivePad != null) drivePad.setPosition(0, 0);
        if (orb != null) {
            synchronized (orb.propToORB) {
                orb.setMotor(ORB.M1, ORB.SPEED_MODE, 0, 0);
                orb.setMotor(ORB.M4, ORB.SPEED_MODE, 0, 0);
            }
        }
        if (text1 != null) text1.setText(R.string.stopped);
    }

    @Override
    protected void onPause() {
        stopMotors();
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) stopMotors();
    }

    private void updatePad(MotionEvent event) {
        float x = 2f * event.getX() / Math.max(1, drivePad.getWidth()) - 1f;
        float y = 1f - 2f * event.getY() / Math.max(1, drivePad.getHeight());
        int[] motors = DriveMixer.mix(x, y, DRIVE_SPEED * 5);
        padM1 = motors[0];
        padM4 = motors[1];
        drivePad.setPosition(x, y);
        text1.setText(getString(R.string.pad_speeds, padM1, padM4));
    }

    //-----------------------------------------------------------------
    class myOnTouchListener implements View.OnTouchListener
    {
        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch(e.getActionMasked())
            {
                case MotionEvent.ACTION_DOWN:
                    if (activeDriveButton != null) {
                        stopMotors();
                        break;
                    }
                    if (!motorsReady || !orb.orb_BT.isConnected()) {
                        stopMotors();
                        text1.setText(R.string.disconnected);
                        break;
                    }
                    activeDriveButton = v;
                    // Keep this gesture even if the finger drifts beyond the button.
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    v.setPressed(true);
                    if (v == drivePad) updatePad(e);
                    driveHandler.removeCallbacks(refreshDrive);
                    refreshDrive.run();
                    if (v == button1) text1.setText(R.string.driving_forward);
                    else if (v == button2) text1.setText(R.string.driving_reverse);
                    else if (v == buttonLeft) text1.setText(R.string.turning_left);
                    else if (v == buttonRight) text1.setText(R.string.turning_right);
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (v == drivePad && activeDriveButton == drivePad) {
                        updatePad(e);
                        driveHandler.removeCallbacks(refreshDrive);
                        refreshDrive.run();
                    }
                    // The timer refreshes commands even when the finger does not move.
                    // Moving outside the button must not send a stop command.
                    break;
                case MotionEvent.ACTION_UP:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    stopMotors();
                    v.setPressed(false);
                    v.performClick();
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_POINTER_DOWN:
                case MotionEvent.ACTION_POINTER_UP:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    stopMotors();
                    v.setPressed(false);
                    break;
                default:return false;
            }
            return true;
        }
    };



}

