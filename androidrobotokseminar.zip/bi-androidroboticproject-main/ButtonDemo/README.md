# ButtonDemo

Separate Android-App auf Basis des MainActivity-Beispiels von Thomas Breuer.

## Starten

1. In Android Studio diesen Ordner `ButtonDemo` als Projekt öffnen.
2. Als Gradle JDK das installierte JDK 21 auswählen (auf diesem Rechner unter `C:\Users\solarscouts\.jdks\jbr-21.0.11`).
3. Gradle Sync ausführen und anschließend die Konfiguration `app` auf einem Emulator oder Android-Gerät starten (Android 6 oder neuer).

Die App hat die eigene Application-ID `com.hbrs.buttondemo` und kann neben RemoteControl installiert werden.

## Verhalten prüfen

Connect öffnet die Bluetooth-Geräteauswahl und konfiguriert M1/M4 mit `(144, 50, 50, 30)`.

- Forward/Reverse/Links/Rechts gedrückt halten: Motorbefehle werden sofort und anschließend alle 100 ms erneuert, auch bei unbewegtem Finger und außerhalb der Buttonfläche.
- Geschwindigkeit: aktuell ±1500 (`DRIVE_SPEED = 500`, Faktor 3). Vorwärts: M1+/M4−; rückwärts: M1−/M4+; links: beide negativ; rechts: beide positiv. Die Drehrichtung setzt M1 links und M4 rechts voraus und muss am Roboter geprüft werden.
- Loslassen, Touch-Abbruch, Mehrfingereingabe, Fokusverlust oder Verlassen der Activity beendet den Timer und setzt beide Geschwindigkeiten auf null.
- Danach ist ein neuer Tastendruck erforderlich. Der separate Stop-Button wurde entfernt; Loslassen stoppt weiterhin.

Die ORB-Bibliothek sendet Motorpakete nur bei `propToORB.isNew`. Der Timer setzt dieses Flag durch wiederholte `setMotor`-Aufrufe. Das Auslesen und Zurücksetzen erfolgt unter derselben Sperre wie das Schreiben, damit neue Fahr-/Stopbefehle nicht verloren gehen.

Lokaler Java-Protokolltest: 100 erneuerte Vorwärts-/Rückwärtsbefehle sowie das Stop-Paket erfolgreich geprüft. Der Timer und das Verhalten am Roboter sind noch nicht praktisch verifiziert. Bei unterbrochener Funkverbindung kann ein Stop-Befehl nicht zuverlässig zugestellt werden.

## Build

```powershell
$env:JAVA_HOME = 'C:\Users\solarscouts\.jdks\jbr-21.0.11'
.\gradlew.bat assembleDebug lintDebug
```

Die APK liegt nach erfolgreichem Build unter `app/build/outputs/apk/debug/app-debug.apk`.

Prüfstand: XML-Dateien und Ressourcenreferenzen statisch geprüft. Der lokale Buildversuch scheitert bereits beim Start der Gradle-Kommunikation mit `java.io.IOException: Unable to establish loopback connection` (Windows-Socket-Fehler), bevor die App kompiliert wird. Build, Lint und Gerätetest sind deshalb noch nicht bestätigt.



## Steuerpad

Unter den Fahrbuttons liegt ein 300dp hohes Pad mit Fingeranzeige. Die Ansicht ist auf kleinen Bildschirmen scrollbar; beim Steuern bleibt die Touch-Geste am Pad.

Die Mitte hat eine 8%-Ruhezone je Achse. Oben/unten erhöht sich das Tempo stufenlos bis ±2500 (`DRIVE_SPEED * 5`). Rechts/links wird eine Drehkomponente zugemischt. Auf der horizontalen Mittellinie dreht der Roboter auf der Stelle. Die Mischung wird gemeinsam skaliert, damit kein Motor ±2500 überschreitet. Die Zuordnung übernimmt die aktuell angepassten Links-/Rechtsbuttons (M1 rechtes Rad, M4 linkes Rad mit umgekehrter Polarität).

Pad-Befehle werden beim Ziehen sofort und beim Halten alle 100 ms erneuert. Loslassen, Touch-Abbruch, Mehrfingereingabe oder Fokusverlust stoppt und setzt den Punkt in die Mitte zurück. Die bestehenden Fahrbuttons behalten Faktor 3.

Die Mischfunktion und Pad-View wurden separat mit javac kompiliert. Der lokale Rechentest deckt Neutralzone, Randpositionen, Kurven, Begrenzung außerhalb des Pads, monotones Tempo und 40401 Positionen innerhalb des Tempolimits ab. Android-Gesamtbuild und Roboter-/Darstellungstest stehen noch aus.
